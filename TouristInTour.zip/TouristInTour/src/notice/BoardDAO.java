package notice;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class BoardDAO {
	// 게시판 데이터베이스 접근을 위한 DAO 클래스 정의
	private DataSource dataFactory;
	// 데이터베이스 연결을 위한 DataSource
	Connection conn;
	// 데이터베이스 연결 객체
	PreparedStatement pstmt;
	// PreparedStatement 객체

	public BoardDAO() {
		// BoardDAO 생성자
		try {
			// JNDI를 통해 데이터베이스 연결 정보 가져오기
			Context ctx = new InitialContext();
			// JNDI 초기 컨텍스트 생성
			Context envContext = (Context) ctx.lookup("java:/comp/env");
			// 환경 컨텍스트 조회
			dataFactory = (DataSource) envContext.lookup("jdbc/oracle");
			// DataSource 객체 조회
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}
	}

	public List selectAllArticles(Map pagingMap){
		// 모든 게시글을 조회하는 메소드
		List articlesList = new ArrayList();
		// 게시글 리스트 초기화
		int section = (Integer)pagingMap.get("section");
		// 현재 섹션
		int pageNum=(Integer)pagingMap.get("pageNum");
		// 현재 페이지 번호
		try{
		   conn = dataFactory.getConnection();
		// 데이터베이스 연결 얻기
		   String query ="SELECT * FROM ( "
						+ "select ROWNUM  as recNum,"+"LVL," // 행 번호를 recNum으로 정의
							+"articleNO,"
							+"parentNO,"
							+"title,"
							+"id,"
							+"writeDate"
				                  +" from (select LEVEL as LVL, "
								+"articleNO,"
								+"parentNO,"
								+"title,"
								+"id,"
								 +"writeDate"
							   +" from t_board" 
							   +" START WITH  parentNO=0"
							   +" CONNECT BY PRIOR articleNO = parentNO"
							  +"  ORDER SIBLINGS BY articleNO DESC)"
					+") "                        
					+" where recNum between(?-1)*100+(?-1)*10+1 and (?-1)*100+?*10";
		   // 게시글 조회 쿼리 작성 (계층형 쿼리)
		   System.out.println(query);
		   // 쿼리 출력
		   pstmt= conn.prepareStatement(query);
		   // PreparedStatement 생성
		   pstmt.setInt(1, section);
		   // 섹션 번호 설정
		   pstmt.setInt(2, pageNum);
		   // 페이지 번호 설정
		   pstmt.setInt(3, section);
		   // 섹션 번호 설정 (쿼리의 두 번째 인스턴스)
		   pstmt.setInt(4, pageNum);
		   // 페이지 번호 설정 (쿼리의 두 번째 인스턴스)
		   ResultSet rs =pstmt.executeQuery();
		   // 쿼리 실행 및 결과 집합 얻기
		   while(rs.next()){
			// 결과 집합을 순회
		      int level = rs.getInt("lvl");
		   // 레벨 값 읽기
		      int articleNO = rs.getInt("articleNO");
		   // 게시글 번호 읽기
		      int parentNO = rs.getInt("parentNO");
		   // 부모 게시글 번호 읽기
		      String title = rs.getString("title");
		   // 제목 읽기
		      String id = rs.getString("id");
		   // 작성자 ID 읽기
		      Date writeDate= rs.getDate("writeDate");
		   // 작성일 읽기
		      ArticleVO article = new ArticleVO();
		   // ArticleVO 객체 생성
		      article.setLevel(level);
		   // 레벨 설정
		      article.setArticleNO(articleNO);
		   // 게시글 번호 설정
		      article.setParentNO(parentNO);
		   // 부모 게시글 번호 설정
		      article.setTitle(title);
		   // 제목 설정
		      article.setId(id);
		   // 작성자 ID 설정
		      article.setWriteDate(writeDate);
		   // 작성일 설정
		      articlesList.add(article);	
		   // 리스트에 추가
		   } //end while
		   rs.close();
		   // ResultSet 닫기
		   pstmt.close();
		// PreparedStatement 닫기
		   conn.close();
		// Connection 닫기
	  }catch(Exception e){
	     e.printStackTrace();	
	  // 예외 발생 시 스택 트레이스 출력
	  }
	  return articlesList;
	// 게시글 리스트 반환
    } 
	
	public List selectAllArticles() {
		// 모든 게시글을 조회하는 메소드
		List articlesList = new ArrayList();
		// 게시글 리스트 초기화
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			String query = "SELECT LEVEL,articleNO,parentNO,title,content,id,writeDate" + " from t_board"
					+ " START WITH  parentNO=0" + " CONNECT BY PRIOR articleNO=parentNO"
					+ " ORDER SIBLINGS BY articleNO DESC";
			// 게시글 조회 쿼리 작성 (계층형 쿼리)
			System.out.println(query);
			// 쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			ResultSet rs = pstmt.executeQuery();
			// 쿼리 실행 및 결과 집합 얻기
			while (rs.next()) {
				// 결과 집합을 순회
				int level = rs.getInt("level");
				// 레벨 값 읽기
				int articleNO = rs.getInt("articleNO");
				// 게시글 번호 읽기
				int parentNO = rs.getInt("parentNO");
				// 부모 게시글 번호 읽기
				String title = rs.getString("title");
				// 제목 읽기
				String content = rs.getString("content");
				// 내용 읽기
				String id = rs.getString("id");
				// 작성자 ID 읽기
				Date writeDate = rs.getDate("writeDate");
				// 작성일 읽기
				ArticleVO article = new ArticleVO();
				// ArticleVO 객체 생성
				article.setLevel(level);
				// 레벨 설정
				article.setArticleNO(articleNO);
				// 게시글 번호 설정
				article.setParentNO(parentNO);
				// 부모 게시글 번호 설정
				article.setTitle(title);
				// 제목 설정
				article.setContent(content);
				// 내용 설정
				article.setId(id);
				// 작성자 ID 설정
				article.setWriteDate(writeDate);
				// 작성일 설정
				articlesList.add(article);
				// 리스트에 추가
			}
			rs.close();
			// ResultSet 닫기
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			 // 예외 발생 시 스택 트레이스 출력
		}
		return articlesList;
		// 게시글 리스트 반환
	}


	private int getNewArticleNO() {
		// 새 게시글 번호를 얻는 메소드
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			String query = "SELECT  max(articleNO) from t_board ";
			// 새 게시글 번호를 얻기 위한 쿼리 작성
			System.out.println(query);
			// 쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			ResultSet rs = pstmt.executeQuery(query);
			// 쿼리 실행 및 결과 집합 얻기
			if (rs.next())
				return (rs.getInt(1) + 1);
			// 최대 게시글 번호 + 1 반환
			rs.close();
			// ResultSet 닫기
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}
		return 0;
		// 게시글 번호가 없는 경우 0 반환
	}

	public int insertNewArticle(ArticleVO article) {
		// 새 게시글을 데이터베이스에 삽입하는 메소드
		int articleNO = getNewArticleNO();
		// 새 게시글 번호 얻기
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			int parentNO = article.getParentNO();
			// 부모 게시글 번호
			String title = article.getTitle();
			// 제목
			String content = article.getContent();
			// 내용
			String id = article.getId();
			// 작성자 ID
			String imageFileName = article.getImageFileName();
			// 이미지 파일 이름
			String query = "INSERT INTO t_board (articleNO, parentNO, title, content, imageFileName, id)"
					+ " VALUES (?, ? ,?, ?, ?, ?)";
			// 새 게시글을 삽입하기 위한 쿼리 작성
			System.out.println(query);
			// 쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			pstmt.setInt(1, articleNO);
			// 게시글 번호 설정
			pstmt.setInt(2, parentNO);
			// 부모 게시글 번호 설정
			pstmt.setString(3, title);
			// 제목 설정
			pstmt.setString(4, content);
			// 내용 설정
			pstmt.setString(5, imageFileName);
			// 이미지 파일 이름 설정
			pstmt.setString(6, id);
			// 작성자 ID 설정
			pstmt.executeUpdate();
			// 쿼리 실행
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}

		return articleNO;
		// 새 게시글 번호 반환
	}

	public ArticleVO selectArticle(int articleNO) {
		// 특정 게시글을 조회하는 메소드
		ArticleVO article = new ArticleVO();
		// ArticleVO 객체 생성
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			String query = "select articleNO,parentNO,title,content, NVL(imageFileName, 'null') as imageFileName, id, writeDate" + " from t_board"
					+ " where articleNO=?";
			// 특정 게시글을 조회하기 위한 쿼리 작성
			System.out.println(query);
			// 쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			pstmt.setInt(1, articleNO);
			// 게시글 번호 설정
			ResultSet rs = pstmt.executeQuery();
			// 쿼리 실행 및 결과 집합 얻기
			rs.next();
			// 첫 번째 결과 행으로 이동
			int _articleNO = rs.getInt("articleNO");
			// 게시글 번호 읽기
			int parentNO = rs.getInt("parentNO");
			// 부모 게시글 번호 읽기
			String title = rs.getString("title");
			// 제목 읽기
			String content = rs.getString("content");
			// 내용 읽기
			String imageFileName = URLEncoder.encode(rs.getString("imageFileName"), "UTF-8"); //파일이름에 특수문자가 있을 경우 인코딩합니다.
			// 이미지 파일 이름을 URL 인코딩
			if(imageFileName.equals("null")) {
				imageFileName = null;
				// 'null' 문자열인 경우 null로 설정
			}
			
			String id = rs.getString("id");
			// 작성자 ID 읽기
			Date writeDate = rs.getDate("writeDate");
			// 작성일 읽기

			article.setArticleNO(_articleNO);
			article.setParentNO(parentNO);
			article.setTitle(title);
			article.setContent(content);
			article.setImageFileName(imageFileName);
			article.setId(id);
			article.setWriteDate(writeDate);
			// ArticleVO 객체에 값 설정
			rs.close();
			// ResultSet 닫기
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}
		return article;
		// ArticleVO 객체 반환
	}

	public void updateArticle(ArticleVO article) {
		// 게시글을 업데이트하는 메소드
		int articleNO = article.getArticleNO();
		// 게시글 번호
		String title = article.getTitle();
		// 게시글 번호
		String content = article.getContent();
		// 내용
		String imageFileName = article.getImageFileName();
		// 이미지 파일 이름
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			String query = "update t_board  set title=?,content=?";
			if (imageFileName != null && imageFileName.length() != 0) {
				query += ",imageFileName=?";
			}
			query += " where articleNO=?";
			// 게시글 업데이트 쿼리 작성 (이미지 파일 이름이 있을 경우 추가)
			System.out.println(query);
			// 쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			pstmt.setString(1, title);
			// 제목 설정
			pstmt.setString(2, content);
			// 내용 설정
			if (imageFileName != null && imageFileName.length() != 0) {
				pstmt.setString(3, imageFileName);
				// 이미지 파일 이름 설정
				pstmt.setInt(4, articleNO);
				// 게시글 번호 설정
			} else {
				pstmt.setInt(3, articleNO);
				// 게시글 번호 설정
			}
			pstmt.executeUpdate();
			// 쿼리 실행
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}
	}

	public void deleteArticle(int articleNO) {
		// 게시글을 삭제하는 메소드
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			String query = "DELETE FROM t_board ";
			query += " WHERE articleNO in (";
			query += "  SELECT articleNO FROM  t_board ";
			query += " START WITH articleNO = ?";
			query += " CONNECT BY PRIOR  articleNO = parentNO )";
			// 계층형 쿼리를 사용하여 삭제할 게시글 및 하위 게시글을 선택하는 쿼리 작성
			System.out.println(query);
			// 쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			pstmt.setInt(1, articleNO);
			// 게시글 번호 설정
			pstmt.executeUpdate();
			// 쿼리 실행
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}
	}

	public List<Integer> selectRemovedArticles(int articleNO) {
		// 특정 게시글 및 하위 게시글의 번호를 조회하는 메소드
		List<Integer> articleNOList = new ArrayList<Integer>();
		// 게시글 번호 리스트 초기화
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			String query = "SELECT articleNO FROM  t_board  ";
			query += " START WITH articleNO = ?";
			query += " CONNECT BY PRIOR  articleNO = parentNO";
			// 계층형 쿼리를 사용하여 삭제할 게시글 및 하위 게시글 번호를 선택하는 쿼리 작성
			System.out.println(query); //쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			pstmt.setInt(1, articleNO);
			// 게시글 번호 설정
			ResultSet rs = pstmt.executeQuery();
			// 쿼리 실행 및 결과 집합 얻기
			while (rs.next()) {
				// 결과 집합을 순회
				articleNO = rs.getInt("articleNO");
				// 게시글 번호 읽기
				articleNOList.add(articleNO);
				// 리스트에 추가
			}
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}
		return articleNOList;
		// 게시글 번호 리스트 반환
	}

	public int selectTotArticles() {
		// 총 게시글 수를 조회하는 메소드
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결 얻기
			String query = "select count(articleNO) from t_board ";
			// 총 게시글 수를 조회하는 쿼리 작성
			System.out.println(query); //쿼리 출력
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 생성
			ResultSet rs = pstmt.executeQuery();
			// 쿼리 실행 및 결과 집합 얻기
			if (rs.next())
				return (rs.getInt(1));
			// 총 게시글 수 반환
			rs.close();
			// ResultSet 닫기
			pstmt.close();
			// PreparedStatement 닫기
			conn.close();
			// Connection 닫기
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스 출력
		}
		return 0;
		// 게시글이 없는 경우 0 반환
	}
}
