package notice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BoardService {
	BoardDAO boardDAO;
	// BoardDAO 객체를 참조할 필드

	public BoardService() {
		// BoardService 클래스의 생성자
		boardDAO = new BoardDAO();
		// BoardDAO 객체를 생성하여 필드에 할당
	}

	public Map listArticles(Map<String, Integer> pagingMap) {
		// 게시글 목록과 총 게시글 수를 반환하는 메소드
		Map articlesMap = new HashMap();
		// 결과를 저장할 Map 객체 생성
		List<ArticleVO> articlesList = boardDAO.selectAllArticles(pagingMap);
		// 페이지에 맞는 게시글 목록 조회
		int totArticles = boardDAO.selectTotArticles();
		// 총 게시글 수 조회
		articlesMap.put("articlesList", articlesList);
		// 게시글 목록을 Map에 저장
		articlesMap.put("totArticles", totArticles);
		// 총 게시글 수를 Map에 저장
		//articlesMap.put("totArticles", 170);
		return articlesMap;
		// 결과를 담은 Map 반환
	}

	public List<ArticleVO> listArticles() {
		// 전체 게시글 목록을 반환하는 메소드
		List<ArticleVO> articlesList = boardDAO.selectAllArticles();
		// 전체 게시글 목록 조회
		return articlesList;
		// 게시글 목록 반환
	}

	public int addArticle(ArticleVO article) {
		// 새 게시글을 추가하는 메소드
		return boardDAO.insertNewArticle(article);
		// BoardDAO를 통해 새 게시글 추가 및 게시글 번호 반환
	}

	public ArticleVO viewArticle(int articleNO) {
		// 특정 게시글을 조회하는 메소드
		ArticleVO article = null;
		// 게시글 객체 초기화
		article = boardDAO.selectArticle(articleNO);
		// BoardDAO를 통해 특정 게시글 조회
		return article;
		// 조회한 게시글 반환
	}

	public void modArticle(ArticleVO article) {
		// 게시글을 수정하는 메소드
		boardDAO.updateArticle(article);
		
	}

	public List<Integer> removeArticle(int articleNO) {
		// 특정 게시글 및 그 하위 게시글을 삭제하는 메소드
		List<Integer> articleNOList = boardDAO.selectRemovedArticles(articleNO);
		// 삭제할 게시글 및 하위 게시글 번호 조회
		boardDAO.deleteArticle(articleNO);
		// BoardDAO를 통해 게시글 삭제
		return articleNOList;
		// 삭제된 게시글 번호 리스트 반환
	}

	public int addReply(ArticleVO article) {
		// 댓글을 추가하는 메소드
		return boardDAO.insertNewArticle(article);
		// BoardDAO를 통해 새 댓글 추가 및 댓글 번호 반환
	}

}
