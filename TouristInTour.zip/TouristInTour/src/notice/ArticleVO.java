package notice;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Date;

public class ArticleVO {
	private int level;
	// 게시글의 레벨
	private int articleNO;
	// 게시글 번호
	private int parentNO;
	// 부모 게시글 번호
	private String title;
	// 게시글 제목
	private String content;
	// 게시글 내용
	private String imageFileName;
	// 이미지 파일명
	private String id;
	// 게시글 작성자 ID
	private Date writeDate;
	// 게시글 작성일
	
	public ArticleVO() {
	// 기본 생성자
	}

	public ArticleVO(int level, int articleNO, int parentNO, String title, String content, String imageFileName,
			String id) {
		// 모든 필드를 초기화하는 생성자
		super();
		// 부모 클래스인 Object의 생성자를 호출
		this.level = level;
		// 레벨 초기화
		this.articleNO = articleNO;
		// 게시글 번호 초기화
		this.parentNO = parentNO;
		// 부모 게시글 번호 초기화
		this.title = title;
		// 제목 초기화
		this.content = content;
		// 내용 초기화
		this.imageFileName = imageFileName;
		// 이미지 파일 이름 초기화
		this.id = id;
		// 작성자 ID 초기화
	}

	public int getLevel() {
		// level 필드의 getter 메소드
		return level;
		// 레벨 값을 반환
	}
	public void setLevel(int level) {
		// level 필드의 setter 메소드
		this.level = level;
		// 레벨 값을 설정
	}


	public int getArticleNO() {
		// articleNO 필드의 getter 메소드
		return articleNO;
		// 게시글 번호 값을 반환
	}


	public void setArticleNO(int articleNO) {
		// articleNO 필드의 setter 메소드
		this.articleNO = articleNO;
		// 게시글 번호 값을 설정
	}


	public int getParentNO() {
		// parentNO 필드의 getter 메소드
		return parentNO;
		// 부모 게시글 번호 값을 반환
	}


	public void setParentNO(int parentNO) {
		// parentNO 필드의 setter 메소드
		this.parentNO = parentNO;
		// 부모 게시글 번호 값을 설정
	}


	public String getTitle() {
		// title 필드의 getter 메소드
		return title;
		// 제목 값을 반환
	}


	public void setTitle(String title) {
		// title 필드의 setter 메소드
		this.title = title;
		// 제목 값을 설정
	}


	public String getContent() {
		// content 필드의 getter 메소드
		return content;
		// 내용 값을 반환
	}


	public void setContent(String content) {
		// content 필드의 setter 메소드
		this.content = content;
		// 내용 값을 설정
	}
	
	public String getImageFileName() {
		// imageFileName 필드의 getter 메소드
		try {
			if (imageFileName != null && imageFileName.length() != 0) {
				// 이미지 파일명이 null이 아니고 길이가 0이 아니면 URL 디코딩을 시도
				imageFileName = URLDecoder.decode(imageFileName, "UTF-8");
				// URL에서 인코딩된 파일명을 디코딩
			}
		} catch (UnsupportedEncodingException e) {
			// URL 디코딩 중 예외가 발생하면 스택 트레이스를 출력
			e.printStackTrace();
		}
		return imageFileName;
		// 디코딩된 이미지 파일명 값을 반환
	}

	public void setImageFileName(String imageFileName) {
		// imageFileName 필드의 setter 메소드
		try {
			if(imageFileName!=null && imageFileName.length()!=0) {
				// 이미지 파일명이 null이 아니고 길이가 0이 아니면 URL 인코딩을 시도
				this.imageFileName = URLEncoder.encode(imageFileName, "UTF-8");  //파일이름에 특수문자가 있을 경우 인코딩합니다.
				// 파일 이름에 특수 문자가 있을 경우 URL 인코딩을 수행하여 저장
			}else {
				this.imageFileName = imageFileName;
				// 이미지 파일명이 없으면 그대로 설정
			}
		} catch (UnsupportedEncodingException e) {
			// URL 인코딩 중 예외가 발생하면 스택 트레이스를 출력
			e.printStackTrace();
		}
	}
	public String getId() {
		// id 필드의 getter 메소드
		return id;
		// 작성자 ID 값을 반환
	}


	public void setId(String id) {
		// id 필드의 setter 메소드
		this.id = id;
		// 작성자 ID 값을 설정
	}


	public Date getWriteDate() {
		// writeDate 필드의 getter 메소드
		return writeDate;
		// 작성일 값을 반환
	}


	public void setWriteDate(Date writeDate) {
		// writeDate 필드의 setter 메소드
		this.writeDate = writeDate;
		// 작성일 값을 설정
	}
	
	
	
	
	

}
