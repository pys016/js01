package member;

import java.sql.Date;
// encapsulation // 정보보호 // 캡슐화
public class MemberVO { // 회원 정보를 저장하는 클래스
	private String id; // 회원 ID
	private String pwd; // 회원 비밀번호
	private String name; // 회원 이름

	private String email; // 회원 이메일
	private String address; // 회원 이메일
	private Date joinDate; // 회원 가입일
	//생성자
	public MemberVO() { // 생성자
		System.out.println("MemberVO 생성자 호출"); // 생성자 호출 시 로그 출력
	}

	public MemberVO(String id, String pwd, String name, String email, String address) {
		// ID, 비밀번호, 이름, 이메일, 주소를 인자로 받는 생성자
		this.id = id; // 회원 ID 설정
		this.pwd = pwd; // 회원 비밀번호 설정
		this.name = name; // 회원 이름 설정
		this.email = email; // 회원 이메일 설정
		this.address = address; // 회원 주소 설정
	}
	
	public MemberVO(String id, String pwd, String name, String email, String address, Date joinDate) {
		// ID, 비밀번호, 이름, 이메일, 주소, 가입일을 인자로 받는 생성자
		this.id = id; // 회원 ID 설정
		this.pwd = pwd; // 회원 비밀번호 설정
		this.name = name; // 회원 이름 설정
		this.email = email; // 회원 이메일 설정
		this.address = address; // 회원 주소 설정
		this.joinDate = joinDate; // 회원 가입일 설정
	}
		
	public String getId() { // ID getter 메서드
		return id; // 회원 ID 반환
	}

	public void setId(String id) { // ID setter 메서드
		this.id = id; // 회원 ID 설정
	}

	public String getPwd() { // 비밀번호 getter 메서드
		return pwd; // 회원 비밀번호 반환
	}

	public void setPwd(String pwd) { // 비밀번호 setter 메서드
		this.pwd = pwd; // 회원 비밀번호 설정
	} 

	public String getName() { // 이름 getter 메서드
		return name; // 회원 이름 반환
	}

	public void setName(String name) { // 이름 setter 메서드
		this.name = name; // 회원 이름 설정
	}


	public String getEmail() { // 이메일 getter 메서드
		return email; // 회원 이메일 반환
	}

	public void setEmail(String email) { // 이메일 setter 메서드
		this.email = email; // 회원 이메일 설정
	}

	public String getAddress() { // 주소 getter 메서드
		return address; // 회원 주소 반환
	}
	
	public void setAddress(String address) { // 주소 setter 메서드
		this.address = address; // 회원 주소 설정
	} 

	public Date getJoinDate() { // 가입일 getter 메서드
		return joinDate; // 회원 가입일 반환
	}

	public void setJoinDate(Date joinDate) { // 가입일 setter 메서드
		this.joinDate = joinDate;// 회원 가입일 설정
	}

	
}
