package member;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDAO { // 데이터베이스 작업을 처리하는 DAO 클래스
	private Connection conn; // Oracle DB // 데이터베이스 연결을 위한 Connection 객체
	private PreparedStatement pstmt; // SQL // SQL 쿼리 실행을 위한 PreparedStatement 객체
	private DataSource dataFactory; // 저장소 // 데이터베이스 커넥션 풀을 제공하는 DataSource 객체
 
	//생성자 method /오라클 연결
	public MemberDAO() { // 생성자
		try {
			Context ctx = new InitialContext(); // InitialContext 객체 생성
			Context envContext = (Context) ctx.lookup("java:/comp/env"); // 환경 컨텍스트 조회
			dataFactory = (DataSource) envContext.lookup("jdbc/oracle"); // 데이터 소스 조회
		} catch (Exception e) { // 예외 처리
			e.printStackTrace(); // 예외 스택 트레이스 출력
		}
	}
	//회원 전체보기
	public List<MemberVO> listMembers() { // 회원 목록을 반환하는 메서드
		List<MemberVO> membersList = new ArrayList<MemberVO>(); // 회원 정보를 담을 ArrayList 생성
		try {
			// connDB();
			conn = dataFactory.getConnection(); // 데이터 소스에서 연결을 가져온다
			String query = "select * from t_member order by joinDate desc"; // 실행할 SQL 쿼리
			System.out.println(query); // 쿼리 로그 출력
			pstmt = conn.prepareStatement(query); // PreparedStatement 객체 생성
			ResultSet rs = pstmt.executeQuery(); // 쿼리 실행 및 결과 집합 반환
			while (rs.next()) { // 결과 집합의 각 행을 반복
				String id = rs.getString("id"); // 결과 집합에서 id 컬럼 값 가져오기
				String pwd = rs.getString("pwd"); // 결과 집합에서 pwd 컬럼 값 가져오기
				String name = rs.getString("name"); // 결과 집합에서 name 컬럼 값 가져오기
				String email = rs.getString("email"); // 결과 집합에서 email 컬럼 값 가져오기
				String address = rs.getString("address"); // 결과 집합에서 address 컬럼 값 가져오기
				Date joinDate = rs.getDate("joinDate"); // 결과 집합에서 joinDate 컬럼 값 가져오기
				MemberVO memberVO = new MemberVO(id, pwd, name, email, address, joinDate); // MemberVO 객체 생성
				membersList.add(memberVO);
				
				/*
				vo.setId(id); // MemberVO 객체에 ID 설정
				vo.setPwd(pwd); // MemberVO 객체에 비밀번호 설정
				vo.setName(name); // MemberVO 객체에 이름 설정
				vo.setEmail(email); // MemberVO 객체에 이메일 설정
				vo.setJoinDate(joinDate); // MemberVO 객체에 가입일 설정
				list.add(vo); // 리스트에 MemberVO 객체 추가
				*/
			}
			rs.close(); // ResultSet 객체 닫기
			pstmt.close();// PreparedStatement 객체 닫기
			conn.close(); // Connection 객체 닫기
		} catch (Exception e) { // 예외 처리
			e.printStackTrace(); // 예외 스택 트레이스 출력
		}
		return membersList;
		/*
		return list; // 회원 목록 반환
		*/
	}
	// 회원등록
	public void addMember(MemberVO memberVO) { // 회원 추가 메서드
		try {
			conn = dataFactory.getConnection(); // 데이터 소스에서 연결을 가져온다
			String id = memberVO.getId(); // MemberVO 객체에서 ID 값 가져오기
			String pwd = memberVO.getPwd(); // MemberVO 객체에서 비밀번호 값 가져오기
			String name = memberVO.getName(); // MemberVO 객체에서 이름 값 가져오기
			String email = memberVO.getEmail(); // MemberVO 객체에서 이메일 값 가져오기
			String address = memberVO.getAddress(); // MemberVO 객체에서 주소 값 가져오기
			String query = "insert into t_member"; // 실행할 SQL 쿼리 시작 부분
			query += " (id,pwd,name,email,address)"; // 쿼리에서 삽입할 컬럼 명시
			query += " values(?,?,?,?,?)"; // 쿼리에서 값 삽입 위치 명시
			System.out.println("prepareStatememt: " + query); // 쿼리 로그 출력
			pstmt = conn.prepareStatement(query); // PreparedStatement 객체 생성
			pstmt.setString(1, id); // 첫 번째 파라미터에 ID 값 설정
			pstmt.setString(2, pwd); // 두 번째 파라미터에 비밀번호 값 설정
			pstmt.setString(3, name); // 세 번째 파라미터에 이름 값 설정
			pstmt.setString(4, email); // 네 번째 파라미터에 이메일 값 설정
			pstmt.setString(5, address); // 다섯 번째 파라미터에 주소 값 설정
			pstmt.executeUpdate();  // 쿼리 실행
			pstmt.close(); // PreparedStatement 객체 닫기
		} catch (Exception e) { // 예외 처리
			e.printStackTrace(); // 예외 스택 트레이스 출력
		}
	}
	// 수정 전 회원찾기
	public MemberVO findMember(String id) {
		MemberVO memInfo = null;
		// MemberVO 객체를 저장할 변수 초기화
		try {
			conn = dataFactory.getConnection();
			// 데이터베이스 연결을 가져옴
			String query = "select * from  t_member where id=?";
			// 쿼리 작성: id가 일치하는 레코드를 선택
			pstmt = conn.prepareStatement(query);
			// PreparedStatement 객체 생성
			pstmt.setString(1, id);
			// id 파라미터를 쿼리에 설정
			System.out.println(query);
			// 쿼리 출력
			ResultSet rs = pstmt.executeQuery(); // 쿼리 실행
			rs.next();
			// 결과 집합에서 첫 번째 행으로 이동
			// 각 컬럼 값을 MemberVO 객체에 설정
			//String id = rs.getString("id");
			String pwd = rs.getString("pwd");
			String name = rs.getString("name");
			String email = rs.getString("email");
			String address = rs.getString("address");
			Date joinDate = rs.getDate("joinDate");
			memInfo = new MemberVO(id, pwd, name, email, address, joinDate);
			// MemberVO 객체를 생성하고 조회된 정보를 설정
			pstmt.close();
			conn.close();
			// PreparedStatement와 Connection 객체를 닫음
		} catch (Exception e) {
			e.printStackTrace();
			// 예외 발생 시 스택 트레이스를 출력
		}
		return memInfo;
		// 조회된 MemberVO 객체를 반환
	}
	// 수정
	public void modMember(MemberVO memberVO) { 
		// 회원 정보를 수정하는 메서드
		String id = memberVO.getId(); // MemberVO 객체에서 ID 값 가져오기
		String pwd = memberVO.getPwd(); // MemberVO 객체에서 비밀번호 값 가져오기
		String name = memberVO.getName(); // MemberVO 객체에서 이름 값 가져오기
		String email = memberVO.getEmail(); // MemberVO 객체에서 이메일 값 가져오기
		String address = memberVO.getAddress(); // MemberVO 객체에서 주소 값 가져오기
		try {
			conn = dataFactory.getConnection(); // 데이터 소스에서 연결을 가져온다
			String query = "update t_member set pwd=?,name=?,email=?,address=?  where id=?";
			// 쿼리 작성: 특정 id에 대한 멤버 정보를 업데이트
			System.out.println(query); // 쿼리 로그 출력
			pstmt = conn.prepareStatement(query); // PreparedStatement 객체 생성
			pstmt.setString(1, pwd); // 첫 번째 파라미터에 비밀번호 값 설정
			pstmt.setString(2, name); // 두 번째 파라미터에 이름 값 설정
			pstmt.setString(3, email); // 세 번째 파라미터에 이메일 값 설정
			pstmt.setString(4, address); // 네 번째 파라미터에 주소 값 설정
			pstmt.setString(5, id); // 다섯 번째 파라미터에 ID 값 설정
			pstmt.executeUpdate(); // 쿼리 실행
			pstmt.close(); // PreparedStatement 객체 닫기
			conn.close(); // Connection 객체 닫기
		} catch (Exception e) { // 예외 처리
			e.printStackTrace();
			// 예외 스택 트레이스 출력
		}
	}
	// 회원탈퇴
	public void delMember(String id) { // 회원 삭제 메서드
		try {
			conn = dataFactory.getConnection(); // 데이터 소스에서 연결을 가져온다
			String query = "delete from t_member"  + " where id=?"; // 실행할 SQL 쿼리
			System.out.println("prepareStatememt:" + query); // 쿼리 로그 출력
			pstmt = conn.prepareStatement(query); // PreparedStatement 객체 생성
			pstmt.setString(1, id); // 첫 번째 파라미터에 ID 값 설정
			pstmt.executeUpdate(); // 쿼리 실행
			pstmt.close(); // PreparedStatement 객체 닫기
		} catch (Exception e) { // 예외 처리
			e.printStackTrace(); // 예외 스택 트레이스 출력
		}
	}

}
