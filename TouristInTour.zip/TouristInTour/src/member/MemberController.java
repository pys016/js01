package member;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MemberController
 */
@WebServlet("/member/*") // /* 디자인패턴
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// Oracle DB의 연결하기 위해
	MemberDAO memberDAO; // 데이터베이스 작업을 수행할 DAO 객체

	
	@Override //부모의 것을 바꾸겠다
	public void init(ServletConfig config) throws ServletException {
		// 처음부터 Oracle DB의 연결 - 속도 개선
		memberDAO = new MemberDAO(); // MemberDAO 객체를 생성
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
		// HTTP GET 요청을 처리하기 위해 doHandle 메서드를 호출
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
		// HTTP POST 요청을 처리하기 위해 doHandle 메서드를 호출
	}
	
	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// forwording 경로
		String nextPage = null;
		// 1. request
		request.setCharacterEncoding("utf-8");  // 요청의 문자 인코딩을 UTF-8로 설정
		// url 경로 알아내기
		String action = request.getPathInfo();
		// 요청된 URL의 경로 정보를 추출
		System.out.println("action:" + action);
		// 경로 정보 출력

		
		// 비지니스 로직
		if(action.equals("/join.do")) {
			nextPage = "/join.jsp";
		}
		// login.do
		else if(action.equals("/login.do")) {
			nextPage = "/login.jsp";
		}
		// 조회 /listMembers.do
		if (action.equals("/listMembers.do")) {
			// 요청 경로에 따라 처리할 작업을 결정
			List<MemberVO> membersList = memberDAO.listMembers();
			// /listMembers.do 경로가 요청되면 전체 멤버 목록을 조회
			// binding
			request.setAttribute("membersList", membersList);
			// 조회한 멤버 목록을 request 객체에 저장
			nextPage = "/listMembers.jsp";
			// 멤버 목록을 표시할 JSP 페이지 경로 설정
		}
		else if (action.equals("/memberForm.do")) {
			// /memberForm.do 경로가 요청되면 멤버 등록 폼 페이지로 이동
			nextPage = "/memberForm.jsp";

			// 등록
		} 
		else if (action.equals("/addMember.do")) {
		// /addMember.do 경로가 요청되면 새로운 멤버 정보를 추가
			String id = request.getParameter("id"); // 요청 파라미터에서 id 추출
			String pwd = request.getParameter("pwd"); // 요청 파라미터에서 pwd 추출
			String name = request.getParameter("name"); // 요청 파라미터에서 name 추출
			String email = request.getParameter("email"); // 요청 파라미터에서 email 추출
			String address = request.getParameter("address"); // 요청 파라미터에서 address 추출
			MemberVO memberVO = new MemberVO(id, pwd, name, email, address);
			// 추출한 정보를 사용해 MemberVO 객체 생성
			memberDAO.addMember(memberVO);
			// DAO를 통해 새로운 멤버를 데이터베이스에 추가
			// binding - msg
			request.setAttribute("msg", "addMember");                                                                                                                           
			nextPage = "/listMembers.do";
			// 멤버 목록 페이지로 설정
		}
		// 3. response => View : JSP // 포워딩 (forwarding)/p.272	//forwarding - dispatch
		response.setContentType("text/html;charset=utf-8");
		// 응답의 콘텐츠 타입을 HTML로 설정하고 문자 인코딩을 UTF-8로 설정
		RequestDispatcher dispatch = request.getRequestDispatcher(nextPage);
		dispatch.forward(request, response);
		// 요청을 지정된 JSP 페이지로 포워딩
	}

}
