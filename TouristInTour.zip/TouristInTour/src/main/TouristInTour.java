package main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TouristInTour
 */
@WebServlet("/")
public class TouristInTour extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public TouristInTour() {

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doHandle(request, response);
	}

	private void doHandle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 다음 페이지 경로
		String nextPage = null;
		
		// 1. request
		request.setCharacterEncoding("utf-8");  // 요청의 문자 인코딩을 UTF-8로 설정
		// url 경로 알아내기
		String action = request.getPathInfo();
		System.out.println("action:" + action);
			
		if (action == null) {
			nextPage = "/index.jsp";
		}
		/*
		 // join.do
		else if(action.equals("/join.do")) {
			nextPage = "/join.jsp";
		}
		// login.do
		else if(action.equals("/login.do")) {
			nextPage = "/login.jsp";
		}
		*/
		response.setContentType("text/html;charset=utf-8");
		RequestDispatcher dispatch = request.getRequestDispatcher(nextPage);
		dispatch.forward(request, response);
	}
}
